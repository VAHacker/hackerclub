package gov.va.ptsd.ptsdcoach;

public class Util {

	static {
		gov.va.contentlib.Util.addActionMapping("main", "gov.va.ptsd.ptsdcoach.PTSDCoach");
//		gov.va.contentlib.Util.addActionMapping("main", "gov.va.ptsd.ptsdfamilycoach.PTSDCoach");
	}
}
